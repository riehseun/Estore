<?php
class Product  {
	public $id;
	public $name;
	public $description;
	public $price;
	public $photo_url;	
}
